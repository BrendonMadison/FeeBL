{Spinor[-Momentum[p1], me, 1] . (I*ee*DiracGamma[LorentzIndex[Lor1]]) . 
   Spinor[Momentum[p2], me, 1]*Spinor[Momentum[p4], me, 1] . 
   (I*ee*DiracGamma[LorentzIndex[Lor3]]) . Spinor[-Momentum[p3], me, 1]*
  Spinor[Momentum[p6], mmu, 1] . (I*ee*DiracGamma[LorentzIndex[Lor4]]) . 
   (mmu + DiracGamma[Momentum[p3 + p4 + p6]]) . 
   (I*ee*DiracGamma[LorentzIndex[Lor2]]) . Spinor[-Momentum[p5], mmu, 1]*
  FeynAmpDenominator[PropagatorDenominator[Momentum[-p3 - p4], 0]]*
  FeynAmpDenominator[PropagatorDenominator[Momentum[-p3 - p4 - p6], mmu]]*
  FeynAmpDenominator[PropagatorDenominator[Momentum[p3 + p4 + p5 + p6], 0]]*
  Pair[LorentzIndex[Lor1], LorentzIndex[Lor2]]*Pair[LorentzIndex[Lor3], 
   LorentzIndex[Lor4]], Spinor[-Momentum[p1], me, 1] . 
   (I*ee*DiracGamma[LorentzIndex[Lor1]]) . Spinor[Momentum[p2], me, 1]*
  Spinor[Momentum[p4], me, 1] . (I*ee*DiracGamma[LorentzIndex[Lor3]]) . 
   Spinor[-Momentum[p3], me, 1]*Spinor[Momentum[p6], mmu, 1] . 
   (I*ee*DiracGamma[LorentzIndex[Lor2]]) . 
   (mmu + DiracGamma[Momentum[-p3 - p4 - p5]]) . 
   (I*ee*DiracGamma[LorentzIndex[Lor4]]) . Spinor[-Momentum[p5], mmu, 1]*
  FeynAmpDenominator[PropagatorDenominator[Momentum[-p3 - p4], 0]]*
  FeynAmpDenominator[PropagatorDenominator[Momentum[p3 + p4 + p5], mmu]]*
  FeynAmpDenominator[PropagatorDenominator[Momentum[p3 + p4 + p5 + p6], 0]]*
  Pair[LorentzIndex[Lor1], LorentzIndex[Lor2]]*Pair[LorentzIndex[Lor3], 
   LorentzIndex[Lor4]], Spinor[-Momentum[p1], me, 1] . 
   (I*ee*DiracGamma[LorentzIndex[Lor1]]) . Spinor[Momentum[p2], me, 1]*
  Spinor[Momentum[p6], mmu, 1] . (I*ee*DiracGamma[LorentzIndex[Lor4]]) . 
   Spinor[-Momentum[p5], mmu, 1]*Spinor[Momentum[p4], me, 1] . 
   (I*ee*DiracGamma[LorentzIndex[Lor3]]) . 
   (me + DiracGamma[Momentum[p4 + p5 + p6]]) . 
   (I*ee*DiracGamma[LorentzIndex[Lor2]]) . Spinor[-Momentum[p3], me, 1]*
  FeynAmpDenominator[PropagatorDenominator[Momentum[-p4 - p5 - p6], me]]*
  FeynAmpDenominator[PropagatorDenominator[Momentum[p5 + p6], 0]]*
  FeynAmpDenominator[PropagatorDenominator[Momentum[p3 + p4 + p5 + p6], 0]]*
  Pair[LorentzIndex[Lor1], LorentzIndex[Lor2]]*Pair[LorentzIndex[Lor3], 
   LorentzIndex[Lor4]], Spinor[-Momentum[p1], me, 1] . 
   (I*ee*DiracGamma[LorentzIndex[Lor1]]) . Spinor[Momentum[p2], me, 1]*
  Spinor[Momentum[p6], mmu, 1] . (I*ee*DiracGamma[LorentzIndex[Lor4]]) . 
   Spinor[-Momentum[p5], mmu, 1]*Spinor[Momentum[p4], me, 1] . 
   (I*ee*DiracGamma[LorentzIndex[Lor2]]) . 
   (me + DiracGamma[Momentum[-p3 - p5 - p6]]) . 
   (I*ee*DiracGamma[LorentzIndex[Lor3]]) . Spinor[-Momentum[p3], me, 1]*
  FeynAmpDenominator[PropagatorDenominator[Momentum[p5 + p6], 0]]*
  FeynAmpDenominator[PropagatorDenominator[Momentum[p3 + p5 + p6], me]]*
  FeynAmpDenominator[PropagatorDenominator[Momentum[p3 + p4 + p5 + p6], 0]]*
  Pair[LorentzIndex[Lor1], LorentzIndex[Lor2]]*Pair[LorentzIndex[Lor3], 
   LorentzIndex[Lor4]], 
 -(Spinor[-Momentum[p1], me, 1] . (I*ee*DiracGamma[LorentzIndex[Lor1]]) . 
    Spinor[-Momentum[p3], me, 1]*Spinor[Momentum[p4], me, 1] . 
    (I*ee*DiracGamma[LorentzIndex[Lor3]]) . Spinor[Momentum[p2], me, 1]*
   Spinor[Momentum[p6], mmu, 1] . (I*ee*DiracGamma[LorentzIndex[Lor4]]) . 
    (mmu + DiracGamma[Momentum[-p2 + p4 + p6]]) . 
    (I*ee*DiracGamma[LorentzIndex[Lor2]]) . Spinor[-Momentum[p5], mmu, 1]*
   FeynAmpDenominator[PropagatorDenominator[Momentum[p2 - p4], 0]]*
   FeynAmpDenominator[PropagatorDenominator[Momentum[p2 - p4 - p6], mmu]]*
   FeynAmpDenominator[PropagatorDenominator[Momentum[-p2 + p4 + p5 + p6], 0]]*
   Pair[LorentzIndex[Lor1], LorentzIndex[Lor2]]*Pair[LorentzIndex[Lor3], 
    LorentzIndex[Lor4]]), 
 -(Spinor[-Momentum[p1], me, 1] . (I*ee*DiracGamma[LorentzIndex[Lor1]]) . 
    Spinor[-Momentum[p3], me, 1]*Spinor[Momentum[p4], me, 1] . 
    (I*ee*DiracGamma[LorentzIndex[Lor3]]) . Spinor[Momentum[p2], me, 1]*
   Spinor[Momentum[p6], mmu, 1] . (I*ee*DiracGamma[LorentzIndex[Lor2]]) . 
    (mmu + DiracGamma[Momentum[p2 - p4 - p5]]) . 
    (I*ee*DiracGamma[LorentzIndex[Lor4]]) . Spinor[-Momentum[p5], mmu, 1]*
   FeynAmpDenominator[PropagatorDenominator[Momentum[p2 - p4], 0]]*
   FeynAmpDenominator[PropagatorDenominator[Momentum[-p2 + p4 + p5], mmu]]*
   FeynAmpDenominator[PropagatorDenominator[Momentum[-p2 + p4 + p5 + p6], 0]]*
   Pair[LorentzIndex[Lor1], LorentzIndex[Lor2]]*Pair[LorentzIndex[Lor3], 
    LorentzIndex[Lor4]]), 
 -(Spinor[-Momentum[p1], me, 1] . (I*ee*DiracGamma[LorentzIndex[Lor1]]) . 
    Spinor[-Momentum[p3], me, 1]*Spinor[Momentum[p6], mmu, 1] . 
    (I*ee*DiracGamma[LorentzIndex[Lor4]]) . Spinor[-Momentum[p5], mmu, 1]*
   Spinor[Momentum[p4], me, 1] . (I*ee*DiracGamma[LorentzIndex[Lor3]]) . 
    (me + DiracGamma[Momentum[p4 + p5 + p6]]) . 
    (I*ee*DiracGamma[LorentzIndex[Lor2]]) . Spinor[Momentum[p2], me, 1]*
   FeynAmpDenominator[PropagatorDenominator[Momentum[-p4 - p5 - p6], me]]*
   FeynAmpDenominator[PropagatorDenominator[Momentum[p5 + p6], 0]]*
   FeynAmpDenominator[PropagatorDenominator[Momentum[-p2 + p4 + p5 + p6], 0]]*
   Pair[LorentzIndex[Lor1], LorentzIndex[Lor2]]*Pair[LorentzIndex[Lor3], 
    LorentzIndex[Lor4]]), 
 -(Spinor[-Momentum[p1], me, 1] . (I*ee*DiracGamma[LorentzIndex[Lor1]]) . 
    Spinor[-Momentum[p3], me, 1]*Spinor[Momentum[p6], mmu, 1] . 
    (I*ee*DiracGamma[LorentzIndex[Lor4]]) . Spinor[-Momentum[p5], mmu, 1]*
   Spinor[Momentum[p4], me, 1] . (I*ee*DiracGamma[LorentzIndex[Lor2]]) . 
    (me + DiracGamma[Momentum[p2 - p5 - p6]]) . 
    (I*ee*DiracGamma[LorentzIndex[Lor3]]) . Spinor[Momentum[p2], me, 1]*
   FeynAmpDenominator[PropagatorDenominator[Momentum[p5 + p6], 0]]*
   FeynAmpDenominator[PropagatorDenominator[Momentum[-p2 + p5 + p6], me]]*
   FeynAmpDenominator[PropagatorDenominator[Momentum[-p2 + p4 + p5 + p6], 0]]*
   Pair[LorentzIndex[Lor1], LorentzIndex[Lor2]]*Pair[LorentzIndex[Lor3], 
    LorentzIndex[Lor4]]), 
 -(Spinor[Momentum[p4], me, 1] . (I*ee*DiracGamma[LorentzIndex[Lor2]]) . 
    Spinor[Momentum[p2], me, 1]*Spinor[Momentum[p6], mmu, 1] . 
    (I*ee*DiracGamma[LorentzIndex[Lor4]]) . Spinor[-Momentum[p5], mmu, 1]*
   Spinor[-Momentum[p1], me, 1] . (I*ee*DiracGamma[LorentzIndex[Lor1]]) . 
    (me + DiracGamma[Momentum[-p3 - p5 - p6]]) . 
    (I*ee*DiracGamma[LorentzIndex[Lor3]]) . Spinor[-Momentum[p3], me, 1]*
   FeynAmpDenominator[PropagatorDenominator[Momentum[-p2 + p4], 0]]*
   FeynAmpDenominator[PropagatorDenominator[Momentum[p5 + p6], 0]]*
   FeynAmpDenominator[PropagatorDenominator[Momentum[p3 + p5 + p6], me]]*
   Pair[LorentzIndex[Lor1], LorentzIndex[Lor2]]*Pair[LorentzIndex[Lor3], 
    LorentzIndex[Lor4]]), 
 -(Spinor[Momentum[p4], me, 1] . (I*ee*DiracGamma[LorentzIndex[Lor3]]) . 
    Spinor[Momentum[p2], me, 1]*Spinor[Momentum[p6], mmu, 1] . 
    (I*ee*DiracGamma[LorentzIndex[Lor2]]) . Spinor[-Momentum[p5], mmu, 1]*
   Spinor[-Momentum[p1], me, 1] . (I*ee*DiracGamma[LorentzIndex[Lor1]]) . 
    (me + DiracGamma[Momentum[p2 - p3 - p4]]) . 
    (I*ee*DiracGamma[LorentzIndex[Lor4]]) . Spinor[-Momentum[p3], me, 1]*
   FeynAmpDenominator[PropagatorDenominator[Momentum[p2 - p4], 0]]*
   FeynAmpDenominator[PropagatorDenominator[Momentum[-p2 + p3 + p4], me]]*
   FeynAmpDenominator[PropagatorDenominator[Momentum[p5 + p6], 0]]*
   Pair[LorentzIndex[Lor1], LorentzIndex[Lor2]]*Pair[LorentzIndex[Lor3], 
    LorentzIndex[Lor4]]), Spinor[Momentum[p4], me, 1] . 
   (I*ee*DiracGamma[LorentzIndex[Lor2]]) . Spinor[-Momentum[p3], me, 1]*
  Spinor[Momentum[p6], mmu, 1] . (I*ee*DiracGamma[LorentzIndex[Lor4]]) . 
   Spinor[-Momentum[p5], mmu, 1]*Spinor[-Momentum[p1], me, 1] . 
   (I*ee*DiracGamma[LorentzIndex[Lor1]]) . 
   (me + DiracGamma[Momentum[p2 - p5 - p6]]) . 
   (I*ee*DiracGamma[LorentzIndex[Lor3]]) . Spinor[Momentum[p2], me, 1]*
  FeynAmpDenominator[PropagatorDenominator[Momentum[p3 + p4], 0]]*
  FeynAmpDenominator[PropagatorDenominator[Momentum[p5 + p6], 0]]*
  FeynAmpDenominator[PropagatorDenominator[Momentum[-p2 + p5 + p6], me]]*
  Pair[LorentzIndex[Lor1], LorentzIndex[Lor2]]*Pair[LorentzIndex[Lor3], 
   LorentzIndex[Lor4]], Spinor[Momentum[p4], me, 1] . 
   (I*ee*DiracGamma[LorentzIndex[Lor4]]) . Spinor[-Momentum[p3], me, 1]*
  Spinor[Momentum[p6], mmu, 1] . (I*ee*DiracGamma[LorentzIndex[Lor2]]) . 
   Spinor[-Momentum[p5], mmu, 1]*Spinor[-Momentum[p1], me, 1] . 
   (I*ee*DiracGamma[LorentzIndex[Lor1]]) . 
   (me + DiracGamma[Momentum[p2 - p3 - p4]]) . 
   (I*ee*DiracGamma[LorentzIndex[Lor3]]) . Spinor[Momentum[p2], me, 1]*
  FeynAmpDenominator[PropagatorDenominator[Momentum[p3 + p4], 0]]*
  FeynAmpDenominator[PropagatorDenominator[Momentum[-p2 + p3 + p4], me]]*
  FeynAmpDenominator[PropagatorDenominator[Momentum[p5 + p6], 0]]*
  Pair[LorentzIndex[Lor1], LorentzIndex[Lor2]]*Pair[LorentzIndex[Lor3], 
   LorentzIndex[Lor4]]}
